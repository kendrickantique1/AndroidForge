package com.example.smsrelay;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.telephony.SmsMessage;
import android.telephony.SmsManager;
import android.util.Log;
import java.util.ArrayList;
import java.util.Locale;

public class SmsReceiver extends BroadcastReceiver {
    private static String digits(String s) {
        if (s == null) return "";
        StringBuilder out = new StringBuilder();
        for (char c : s.toCharArray()) if (Character.isDigit(c)) out.append(c);
        return out.toString();
    }
    private static boolean matches(String actual, String filter) {
        String a=digits(actual), f=digits(filter);
        if (a.isEmpty() || f.isEmpty()) return false;
        // Compare suffix to support local numbers and +98 forms; use at least last 7 digits.
        int n=Math.min(a.length(),f.length());
        return n>=7 && a.substring(a.length()-n).equals(f.substring(f.length()-n));
    }

    @Override public void onReceive(Context context, Intent intent) {
        SharedPreferences p=context.getSharedPreferences("smsrelay",Context.MODE_PRIVATE);
        if (!p.getBoolean("enabled",false)) return;
        String filter=p.getString("sender","").trim(), dest=p.getString("destination","").trim();
        if(filter.isEmpty() || dest.isEmpty()) return;
        Bundle extras=intent.getExtras(); if(extras==null) return;
        Object[] pdus=(Object[])extras.get("pdus"); if(pdus==null) return;
        String sender="", body="";
        String format=extras.getString("format");
        for(Object item:pdus) {
            SmsMessage m;
            try { m=SmsMessage.createFromPdu((byte[])item,format); }
            catch(Exception ex) { m=SmsMessage.createFromPdu((byte[])item); }
            if(m!=null) { sender=m.getOriginatingAddress(); body+=m.getMessageBody(); }
        }
        if(!matches(sender,filter)) return;
        String forwarded="کد دریافت‌شده از سرشماره عبارت است از:\n"+body;
        try {
            SmsManager manager=SmsManager.getDefault();
            ArrayList<String> parts=manager.divideMessage(forwarded);
            manager.sendMultipartTextMessage(dest,null,parts,null,null);
        } catch(Exception e) { Log.e("SMSRelay","SMS forwarding failed",e); }
    }
}
