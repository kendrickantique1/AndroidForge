package com.example.smsrelay;

import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.*;

public class MainActivity extends Activity {
    EditText senderFilter, destination;
    Switch enabled;
    TextView status;
    static final int PERMISSION_REQUEST = 10;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 32, 28, 24);
        root.setBackgroundColor(Color.rgb(22,24,30));

        TextView title = new TextView(this);
        title.setText("SMS Relay");
        title.setTextSize(26);
        title.setTextColor(Color.WHITE);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("انتقال پیامک با فیلتر سرشماره");
        subtitle.setTextColor(0xffbbbbbb);
        subtitle.setGravity(Gravity.RIGHT);
        root.addView(subtitle);

        senderFilter = field(root, "سرشماره فرستنده (مثلاً 50001234)");
        destination = field(root, "شماره مقصد (مثلاً +989031022312)");

        enabled = new Switch(this);
        enabled.setText("انتقال فعال باشد");
        enabled.setTextColor(Color.WHITE);
        root.addView(enabled);

        Button save = new Button(this);
        save.setText("ذخیره تنظیمات");
        root.addView(save);

        status = new TextView(this);
        status.setTextColor(0xffbbbbbb);
        status.setPadding(0,18,0,0);
        root.addView(status);
        setContentView(root);

        SharedPreferences p = prefs();
        senderFilter.setText(p.getString("sender",""));
        destination.setText(p.getString("destination",""));
        enabled.setChecked(p.getBoolean("enabled",false));

        save.setOnClickListener(v -> saveSettings());
    }

    EditText field(LinearLayout parent, String hint) {
        EditText e = new EditText(this);
        e.setSingleLine(true);
        e.setTextColor(Color.WHITE);
        e.setHintTextColor(0xffaaaaaa);
        e.setHint(hint);
        parent.addView(e);
        return e;
    }

    SharedPreferences prefs() { return getSharedPreferences("smsrelay", MODE_PRIVATE); }

    void saveSettings() {
        String filter = senderFilter.getText().toString().trim();
        String dest = destination.getText().toString().trim();
        if (filter.isEmpty() || dest.isEmpty()) {
            status.setText("سرشماره و شماره مقصد را وارد کنید.");
            return;
        }
        prefs().edit().putString("sender",filter).putString("destination",dest)
                .putBoolean("enabled",enabled.isChecked()).apply();

        if (checkSelfPermission("android.permission.RECEIVE_SMS") != PackageManager.PERMISSION_GRANTED ||
            checkSelfPermission("android.permission.SEND_SMS") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.RECEIVE_SMS","android.permission.SEND_SMS"},PERMISSION_REQUEST);
        } else status.setText("تنظیمات ذخیره شد.");
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode,permissions,results);
        if (requestCode == PERMISSION_REQUEST) {
            boolean ok = true;
            for (int r:results) if (r != PackageManager.PERMISSION_GRANTED) ok=false;
            status.setText(ok ? "مجوزها داده شد؛ تنظیمات ذخیره است." : "برای انتقال پیامک، مجوز SMS لازم است.");
        }
    }
}
