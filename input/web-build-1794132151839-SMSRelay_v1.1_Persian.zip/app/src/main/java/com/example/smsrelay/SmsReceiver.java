package com.example.smsrelay;
import android.content.*;import android.os.Bundle;import android.telephony.SmsMessage;import android.telephony.SmsManager;import android.util.Log;import java.util.ArrayList;
public class SmsReceiver extends BroadcastReceiver{
public void onReceive(Context c,Intent i){SharedPreferences p=c.getSharedPreferences("cfg",0);if(!p.getBoolean("on",false))return;String filter=p.getString("src","").trim(),dest=p.getString("dst","").trim();if(filter.isEmpty()||dest.isEmpty())return;Bundle b=i.getExtras();if(b==null)return;Object[] pd=(Object[])b.get("pdus");if(pd==null)return;String sender="",body="",fmt=b.getString("format");for(Object x:pd){SmsMessage m=SmsMessage.createFromPdu((byte[])x,fmt);if(m!=null){sender=m.getOriginatingAddress();body+=m.getMessageBody();}}
String normSender=sender==null?"":sender.replaceAll("[^0-9]","");String normFilter=filter.replaceAll("[^0-9]","");if(!normSender.endsWith(normFilter))return;
try{SmsManager sm=SmsManager.getDefault();ArrayList<String> parts=sm.divideMessage("کد دریافت‌شده از سرشماره عبارت است از:\n"+body);sm.sendMultipartTextMessage(dest,null,parts,null,null);}catch(Exception e){Log.e("SMSRelay","send failed",e);}}
}
