package com.example.smsrelay;
import android.app.Activity;import android.os.Bundle;import android.content.*;import android.content.pm.PackageManager;import android.widget.*;
public class MainActivity extends Activity{
EditText src,dst;Switch on;TextView info;static final int R=5;
public void onCreate(Bundle b){super.onCreate(b);LinearLayout l=new LinearLayout(this);l.setOrientation(1);l.setPadding(28,35,28,25);
TextView t=new TextView(this);t.setText("SMS Relay | انتقال پیامک");t.setTextSize(23);l.addView(t);
src=f(l,"سرشماره فرستنده (مثلاً 50001234)");dst=f(l,"شماره گوشی مقصد با +98");on=new Switch(this);on.setText("انتقال فعال");l.addView(on);Button save=new Button(this);save.setText("ذخیره تنظیمات");l.addView(save);info=new TextView(this);l.addView(info);setContentView(l);
SharedPreferences p=getSharedPreferences("cfg",0);src.setText(p.getString("src",""));dst.setText(p.getString("dst",""));on.setChecked(p.getBoolean("on",false));
save.setOnClickListener(v->{p.edit().putString("src",src.getText().toString().trim()).putString("dst",dst.getText().toString().trim()).putBoolean("on",on.isChecked()).apply();if(checkSelfPermission("android.permission.RECEIVE_SMS")!=PackageManager.PERMISSION_GRANTED||checkSelfPermission("android.permission.SEND_SMS")!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{"android.permission.RECEIVE_SMS","android.permission.SEND_SMS"},R);else info.setText("تنظیمات ذخیره شد.");});}
EditText f(LinearLayout l,String h){EditText e=new EditText(this);e.setHint(h);l.addView(e);return e;}
}
