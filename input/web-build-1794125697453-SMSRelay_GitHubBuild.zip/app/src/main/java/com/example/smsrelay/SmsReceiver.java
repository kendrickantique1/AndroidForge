package com.example.smsrelay;

import android.content.*;
import android.os.Bundle;
import android.telephony.SmsMessage;
import android.telephony.SmsManager;
import android.util.Log;

public class SmsReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (!"android.provider.Telephony.SMS_RECEIVED".equals(intent.getAction())) return;
        SharedPreferences p=context.getSharedPreferences("cfg",0);
        if(!p.getBoolean("on",false)) return;
        String filter=p.getString("source","").trim(), dest=p.getString("dest","").trim();
        if(filter.isEmpty() || dest.isEmpty()) return;
        Bundle bundle=intent.getExtras(); if(bundle==null) return;
        Object[] pdus=(Object[])bundle.get("pdus"); if(pdus==null) return;
        String format=bundle.getString("format"), sender="", body="";
        for(Object item:pdus){
            SmsMessage m=SmsMessage.createFromPdu((byte[])item,format);
            if(m==null) continue;
            sender=m.getOriginatingAddress(); body+=m.getMessageBody();
        }
        if(sender==null || !sender.replaceAll("[^0-9+]","").endsWith(filter.replaceAll("[^0-9+]",""))) return;
        try {
            // Split long SMS into segments so they are not truncated.
            String prefix="FWD "+sender+": ";
            SmsManager manager=SmsManager.getDefault();
            manager.sendMultipartTextMessage(dest,null,manager.divideMessage(prefix+body),null,null);
            Log.i("SMSRelay","Forwarded SMS from "+sender);
        } catch(Exception e){ Log.e("SMSRelay","Forward failed",e); }
    }
}
