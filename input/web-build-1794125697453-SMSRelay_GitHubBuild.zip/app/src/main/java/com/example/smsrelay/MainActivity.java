package com.example.smsrelay;

import android.app.Activity;
import android.os.Bundle;
import android.content.*;
import android.content.pm.PackageManager;
import android.widget.*;
import android.view.*;
import android.graphics.Color;

public class MainActivity extends Activity {
    EditText source, destination;
    Switch enabled;
    TextView status;
    static final int REQ=77;
    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().getDecorView().setBackgroundColor(Color.rgb(20,22,28));
        LinearLayout root=new LinearLayout(this); root.setOrientation(1); root.setPadding(32,40,32,32);
        TextView title=new TextView(this); title.setText("SMS Relay"); title.setTextSize(26); title.setTextColor(Color.WHITE);
        root.addView(title);
        TextView desc=new TextView(this); desc.setText("انتقال پیامک با فیلتر سرشماره"); desc.setTextColor(0xffbbbbbb); desc.setPadding(0,8,0,24); root.addView(desc);
        source=field("سرشماره فرستنده (مثلاً 50001234)",root);
        destination=field("شماره مقصد گوشی اصلی",root);
        enabled=new Switch(this); enabled.setText("انتقال فعال باشد"); enabled.setTextColor(Color.WHITE); root.addView(enabled);
        Button save=new Button(this); save.setText("ذخیره تنظیمات"); root.addView(save);
        status=new TextView(this); status.setTextColor(0xffaaaaaa); status.setPadding(0,20,0,0); root.addView(status);
        setContentView(root);
        SharedPreferences p=getSharedPreferences("cfg",0);
        source.setText(p.getString("source","")); destination.setText(p.getString("dest","")); enabled.setChecked(p.getBoolean("on",false));
        save.setOnClickListener(v->{
            getSharedPreferences("cfg",0).edit().putString("source",source.getText().toString().trim())
             .putString("dest",destination.getText().toString().trim()).putBoolean("on",enabled.isChecked()).apply();
            if(checkSelfPermission("android.permission.RECEIVE_SMS")!=PackageManager.PERMISSION_GRANTED ||
               checkSelfPermission("android.permission.SEND_SMS")!=PackageManager.PERMISSION_GRANTED){
                requestPermissions(new String[]{"android.permission.RECEIVE_SMS","android.permission.SEND_SMS","android.permission.READ_SMS"},REQ);
            } else status.setText("تنظیمات ذخیره شد.");
        });
        status.setText("برای عملکرد صحیح، مجوز پیامک را تأیید کنید.");
    }
    EditText field(String hint, LinearLayout root){
        EditText e=new EditText(this); e.setHint(hint); e.setHintTextColor(0xff888888); e.setTextColor(Color.WHITE);
        e.setSingleLine(true); e.setPadding(12,12,12,12); root.addView(e); return e;
    }
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){
        super.onRequestPermissionsResult(r,p,g);
        status.setText(r==REQ && g.length>1 && g[0]==0 && g[1]==0 ? "مجوزها تأیید شد؛ تنظیمات ذخیره هستند." : "مجوز SMS لازم است.");
    }
}
